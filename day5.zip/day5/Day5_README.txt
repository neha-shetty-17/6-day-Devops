
📘 README - Day 5: April 2, 2025
Topics Covered:
- CI/CD with Jenkins:
  - Jenkins is an open-source automation server used for:
    - Continuous Integration (CI)
    - Continuous Delivery (CD)
  - Developed in Java
- Key Jenkins Features:
  - Pipelines (Declarative & Scripted)
  - Jenkins Plugins
  - Integration with Git, Docker, etc.
