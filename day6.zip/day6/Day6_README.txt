
📘 README - Day 6: April 3, 2025
Topics Covered:
- Practical Jenkins Pipeline:
  - Creating and running a Jenkins pipeline job
  - Stages: Build, Test, Deploy
  - Using Jenkinsfile for pipeline-as-code
- Final Project Overview:
  - A complete DevOps workflow using Git ➝ Docker ➝ Jenkins ➝ Kubernetes
