
📘 README - Day 2: March 28, 2025
Topics Covered:
- Linux File Permissions:
  - Permissions are split into read (r=4), write (w=2), and execute (x=1)
  - Applied to user, group, and others
  - Use chmod to change permissions. Ex: chmod 755 filename
- Basic Linux Commands:
  - ls: list files and directories
  - cat filename: view or append content to a file
  - nano filename: open file in the GNU Nano editor
  - CTRL + X, then Y, then Enter: Save and exit Nano editor
-AWS account creation