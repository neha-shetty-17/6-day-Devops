
📘 README - Day 4: April 1, 2025
Topics Covered:
- Kubernetes Deep Dive:
  - kubectl: CLI tool to interact with Kubernetes clusters
  - Creating and managing deployments:
    - kubectl create, kubectl get pods, kubectl describe pod, kubectl delete
  - YAML configuration for defining resources
