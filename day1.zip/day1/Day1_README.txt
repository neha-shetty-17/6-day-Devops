
📘 README - Day 1: March 27, 2025
Topics Covered:
- Docker: 
  - Containerization tool used to package applications and dependencies.
  - Commands:
    - docker build, docker run, docker ps, docker stop, docker images
- Kubernetes:
  - Container orchestration system for automating deployment, scaling, and management of containerized applications.
  - Basic concepts: Pods, Deployments, Services.
- Git Bash:
  - Terminal for Windows that emulates a bash environment and includes Git.
  - Common Git Commands:
    - git init, git clone, git add, git commit, git push, git pull, git status
