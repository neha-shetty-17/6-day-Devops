
📘 README - Day 3: March 29, 2025
Topics Covered:
- Docker Advanced:
  - Dockerfile: Script to automate Docker image creation.
  - Docker Compose: Define and run multi-container Docker applications.
- Hands-on Tasks:
  - Create a Dockerfile and build an image.
  - Run containers using docker-compose.yml
